import {ADD_POST, ON_CHANGE_POST_VALUE} from "../../helpers/actionTypes";
import {T_ProfilePage} from "../data";

type T_AddPost = {
    type: typeof ADD_POST,
}
type T_OnChangePostValue = {
    type: typeof ON_CHANGE_POST_VALUE,
    value: string
}

export type T_MainProfile = T_AddPost | T_OnChangePostValue

const initialState: T_ProfilePage = {
    newValueForPost: '',
    postsData: [
        {message: 'title message', likesCount: '5', id: crypto.randomUUID()},
        {message: 'title message', likesCount: '5', id: crypto.randomUUID()},
        {message: 'title message', likesCount: '5', id: crypto.randomUUID()},
    ]
}

export const profilePageReducer = (state = initialState, action: T_MainProfile) => {
    switch (action.type) {
        case "ADD_POST":
            const newPost = {
                message: state.newValueForPost, likesCount: '0', id: crypto.randomUUID()
            }
            return {...state, postsData: [newPost, ...state.postsData], newValueForPost: ''}

        case "ON_CHANGE_POST_VALUE":
            return {...state, newValueForPost: action.value}
        default:
            return state
    }
}