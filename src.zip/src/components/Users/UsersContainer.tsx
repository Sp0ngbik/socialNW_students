import {connect} from "react-redux";
import Users from "./Users";
import {AppDispatch, RootState} from "../../data/redux/store";
import {
    changeFollowStatusAC,
    setNewActivePageAC,
    setUsersFromServerAC,
    T_UserBody,
    T_UsersState
} from "../../data/reducers/usersReducer";
import React from "react";
import axios from "axios";

export type T_UserContainer = {
    users: T_UserBody[],
    activePage: number,
    changeFollowStatus: (userId: number, follow: boolean) => void
    setUsersFromServer: (usersData: T_UserBody[], totalCount: number, error: string | null) => void
    setNewActivePage: (pageNumber: number) => void
    pageSize: number
    totalCount: number
}

class SuperUserContainer extends React.Component <T_UserContainer> {
    componentDidMount() {
        axios.get<T_UsersState>(`https://social-network.samuraijs.com/api/1.0/users?page=${this.props.activePage}`).then(res => {
            const data = res.data
            this.props.setUsersFromServer(data.items, data.totalCount, data.error)
        })
    }

    onPageChangeHandler(pageNumber: number) {
        this.props.setNewActivePage(pageNumber);
        axios.get<T_UsersState>(`https://social-network.samuraijs.com/api/1.0/users?page=${pageNumber}`).then(res => {
            const data = res.data
            this.props.setUsersFromServer(data.items, data.totalCount, data.error)
        })
    }

    render() {
        return <Users {...this.props}
                      onPageChangeHandler={this.onPageChangeHandler.bind(this)}/>;
    }
}

const mapStateToProps = (state: RootState) => {
    return {
        users: state.usersReducer.items,
        activePage: state.usersReducer.activePage,
        pageSize: state.usersReducer.pageSize,
        totalCount: state.usersReducer.totalCount
    }
}

const mapDispatchToProps = (dispatch: AppDispatch) => {
    return {
        changeFollowStatus: (userId: number, follow: boolean) => {
            dispatch(changeFollowStatusAC(userId, follow))
        },
        setUsersFromServer: (userData: T_UserBody[], totalCount: number, error: string | null) => {
            dispatch(setUsersFromServerAC(userData, totalCount, error))
        },
        setNewActivePage: (pageNumber: number) => {
            dispatch(setNewActivePageAC(pageNumber))
        }
    }
}


export const UsersContainer = connect(mapStateToProps, mapDispatchToProps)(SuperUserContainer)